<?php
require_once __DIR__ . '/pages/view.php';
