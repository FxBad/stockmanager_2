<?php
require_once __DIR__ . '/core/auth_check.php';
