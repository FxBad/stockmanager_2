<?php
session_start();
// Capture any accidental output (warnings / includes) so we can return
// a clean JSON response. We'll discard buffer contents before sending JSON.
ob_start();
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../functions.php';

function send_json($payload, $code = 200)
{
    // Discard any buffered output to keep response clean
    if (ob_get_length()) {
        ob_clean();
    }
    http_response_code($code);
    header('Content-Type: application/json');
    echo json_encode($payload);
    // Ensure output is flushed and buffering ended
    if (ob_get_level()) ob_end_flush();
    exit;
}

// Require roles
if (!isset($_SESSION['user_id']) || !in_array(currentUserRole(), ['admin', 'office'], true)) {
    send_json(['success' => false, 'message' => 'Forbidden'], 403);
}

// Only accept POST and JSON or form submissions
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    send_json(['success' => false, 'message' => 'Method not allowed'], 405);
}

// Accept both application/json and form-encoded
$input = $_POST;
if (empty($input)) {
    $raw = file_get_contents('php://input');
    $json = json_decode($raw, true);
    if (json_last_error() === JSON_ERROR_NONE && is_array($json)) {
        $input = $json;
    }
}

if (!isset($input['item_id'])) {
    send_json(['success' => false, 'message' => 'Missing item_id'], 400);
}

$itemId = (int)$input['item_id'];
if ($itemId <= 0) {
    send_json(['success' => false, 'message' => 'Invalid item id'], 400);
}

try {
    if (!itemsSoftDeleteEnabled()) {
        throw new Exception('Soft-delete is not enabled. Please run DB migration for deleted_at/deleted_by columns.');
    }

    // Start transaction
    $pdo->beginTransaction();

    // Fetch current active item data
    $stmt = $pdo->prepare('SELECT * FROM items WHERE id = ? AND ' . activeItemsWhereSql() . ' FOR UPDATE');
    $stmt->execute([$itemId]);
    $item = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$item) {
        $pdo->rollBack();
        send_json(['success' => false, 'message' => 'Item not found'], 404);
    }

    // Prepare history data
    $levelConversion = isset($item['level_conversion']) ? (float)$item['level_conversion'] : (float)$item['unit_conversion'];
    $calculationMode = isset($item['calculation_mode']) ? (string)$item['calculation_mode'] : 'combined';
    $totalStock = calculateEffectiveStock(
        $item['field_stock'],
        $item['unit_conversion'],
        isset($item['level']) ? $item['level'] : null,
        isset($item['has_level']) ? (bool)$item['has_level'] : false,
        [
            'level_conversion' => $levelConversion,
            'qty_conversion' => (float)$item['unit_conversion'],
            'calculation_mode' => $calculationMode
        ]
    );
    $daysCoverage = calculateDaysCoverage(
        $item['field_stock'],
        0,
        $item['unit_conversion'],
        $item['daily_consumption'],
        isset($item['name']) ? $item['name'] : null,
        isset($item['level']) ? $item['level'] : null,
        isset($item['has_level']) ? (bool)$item['has_level'] : false,
        [
            'item_id' => $itemId,
            'category' => isset($item['category']) ? $item['category'] : '',
            'min_days_coverage' => isset($item['min_days_coverage']) ? (int)$item['min_days_coverage'] : 1,
            'level_conversion' => $levelConversion,
            'qty_conversion' => (float)$item['unit_conversion'],
            'calculation_mode' => $calculationMode
        ]
    );

    $resolvedDaily = resolveDailyConsumption($item['daily_consumption'], [
        'item_id' => $itemId,
        'category' => isset($item['category']) ? $item['category'] : '',
        'effective_stock' => $totalStock,
        'min_days_coverage' => isset($item['min_days_coverage']) ? (int)$item['min_days_coverage'] : 1
    ]);

    $historyWarning = null;
    try {
        $schemaFlags = itemSchemaFlags();
        $historyInsert = buildItemHistoryInsert(
            $schemaFlags,
            [
                'item_id' => $itemId,
                'item_name' => isset($item['name']) ? $item['name'] : '',
                'category' => isset($item['category']) ? $item['category'] : '',
                'action' => 'delete',
                'field_stock_old' => $item['field_stock'],
                'field_stock_new' => null,
                'warehouse_stock_old' => 0,
                'warehouse_stock_new' => null,
                'status_old' => $item['status'],
                'status_new' => null,
                'total_stock_old' => $totalStock,
                'total_stock_new' => null,
                'days_coverage_old' => $daysCoverage,
                'days_coverage_new' => null,
                'unit' => ($item['unit'] !== null ? $item['unit'] : ''),
                'unit_conversion' => $item['unit_conversion'],
                'daily_consumption' => isset($resolvedDaily['value']) ? (float)$resolvedDaily['value'] : $item['daily_consumption'],
                'min_days_coverage' => isset($item['min_days_coverage']) ? $item['min_days_coverage'] : 1,
                'changed_by' => isset($_SESSION['user_id']) ? $_SESSION['user_id'] : null,
                'note' => 'soft-deleted via UI (consumption source: ' . (isset($resolvedDaily['source']) ? $resolvedDaily['source'] : 'manual') . ')',
                'level' => isset($item['level']) ? $item['level'] : null,
            ]
        );
        $histStmt = $pdo->prepare($historyInsert['sql']);
        $histStmt->execute($historyInsert['params']);
    } catch (Exception $historyException) {
        $historyWarning = $historyException->getMessage();
    }

    // Soft delete item (archive)
    $includeDeletedBy = db_has_column('items', 'deleted_by');
    if ($includeDeletedBy) {
        $delStmt = $pdo->prepare('UPDATE items SET deleted_at = NOW(), deleted_by = ?, updated_by = ? WHERE id = ? AND ' . activeItemsWhereSql());
        $delStmt->execute([$_SESSION['user_id'], $_SESSION['user_id'], $itemId]);
    } else {
        $delStmt = $pdo->prepare('UPDATE items SET deleted_at = NOW(), updated_by = ? WHERE id = ? AND ' . activeItemsWhereSql());
        $delStmt->execute([$_SESSION['user_id'], $itemId]);
    }

    $pdo->commit();

    if ($historyWarning !== null) {
        $logDir = __DIR__ . DIRECTORY_SEPARATOR . '..' . DIRECTORY_SEPARATOR . 'logs';
        if (!is_dir($logDir)) @mkdir($logDir, 0755, true);
        $logFile = $logDir . DIRECTORY_SEPARATOR . 'error.log';
        $ts = date('Y-m-d H:i:s');
        $msg = "{$ts} | delete-item history warning: {$historyWarning}\n";
        @file_put_contents($logFile, $msg, FILE_APPEND | LOCK_EX);
    }

    send_json([
        'success' => true,
        'message' => $historyWarning === null
            ? 'Item archived'
            : 'Item archived (riwayat perubahan gagal dicatat)'
    ], 200);
} catch (Exception $e) {
    if ($pdo->inTransaction()) {
        $pdo->rollBack();
    }
    // Log full error for debugging
    $logDir = __DIR__ . DIRECTORY_SEPARATOR . '..' . DIRECTORY_SEPARATOR . 'logs';
    if (!is_dir($logDir)) @mkdir($logDir, 0755, true);
    $logFile = $logDir . DIRECTORY_SEPARATOR . 'error.log';
    $ts = date('Y-m-d H:i:s');
    $msg = "{$ts} | delete-item error: " . $e->getMessage() . "\n";
    @file_put_contents($logFile, $msg, FILE_APPEND | LOCK_EX);

    // Return generic message to client
    send_json(['success' => false, 'message' => 'Server error occurred'], 500);
}
