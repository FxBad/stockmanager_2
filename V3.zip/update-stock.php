<?php
require_once __DIR__ . '/pages/update-stock.php';
