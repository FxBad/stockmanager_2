<?php
require_once __DIR__ . '/core/cache_control.php';
